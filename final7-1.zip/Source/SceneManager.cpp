///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// This file contains the implementation of the `SceneManager` class, which is 
// responsible for managing the preparation and rendering of 3D scenes. It 
// handles textures, materials, lighting configurations, and object rendering.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: December 1, 2024
//
// RESPONSIBILITIES:
// - Load, bind, and manage textures in OpenGL.
// - Define materials and lighting properties for 3D objects.
// - Manage transformations and shader configurations.
// - Render complex 3D scenes using basic meshes.
//
// NOTE: This implementation leverages external libraries like `stb_image` for 
// texture loading and GLM for matrix and vector operations.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>

// Shader uniform names
namespace {
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

// Constructor
SceneManager::SceneManager(ShaderManager* pShaderManager) {
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

// Destructor
SceneManager::~SceneManager() {
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

// Texture creation
bool SceneManager::CreateGLTexture(const char* filename, std::string tag) {
	int width, height, colorChannels;
	GLuint textureID;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (image) {
		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else return false;

		glGenerateMipmap(GL_TEXTURE_2D);
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;
		return true;
	}
	return false;
}

// Texture binding
void SceneManager::BindGLTextures() {
	for (int i = 0; i < m_loadedTextures; i++) {
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

// Texture cleanup
void SceneManager::DestroyGLTextures() {
	for (int i = 0; i < m_loadedTextures; i++) {
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

// Utility texture lookup
int SceneManager::FindTextureSlot(std::string tag) {
	for (int i = 0; i < m_loadedTextures; i++) {
		if (m_textureIDs[i].tag == tag) return i;
	}
	return -1;
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material) {
	for (auto& mat : m_objectMaterials) {
		if (mat.tag == tag) {
			material = mat;
			return true;
		}
	}
	return false;
}

// Transformations
void SceneManager::SetTransformations(glm::vec3 scaleXYZ, float Xrot, float Yrot, float Zrot, glm::vec3 positionXYZ) {
	glm::mat4 scale = glm::scale(scaleXYZ);
	glm::mat4 rotX = glm::rotate(glm::radians(Xrot), glm::vec3(1.0f, 0.0f, 0.0f));
	glm::mat4 rotY = glm::rotate(glm::radians(Yrot), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 rotZ = glm::rotate(glm::radians(Zrot), glm::vec3(0.0f, 0.0f, 1.0f));
	glm::mat4 trans = glm::translate(positionXYZ);
	glm::mat4 model = trans * rotZ * rotY * rotX * scale;

	if (m_pShaderManager)
		m_pShaderManager->setMat4Value(g_ModelName, model);
}

// Shader setups
void SceneManager::SetShaderColor(float r, float g, float b, float a) {
	if (m_pShaderManager) {
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
	}
}

void SceneManager::SetShaderTexture(std::string tag) {
	if (m_pShaderManager) {
		int slot = FindTextureSlot(tag);
		m_pShaderManager->setIntValue(g_UseTextureName, true);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
	}
}

void SceneManager::SetTextureUVScale(float u, float v) {
	if (m_pShaderManager)
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

void SceneManager::SetShaderMaterial(std::string tag) {
	OBJECT_MATERIAL mat;
	if (FindMaterial(tag, mat)) {
		m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
	}
}

// Scene texture loading
void SceneManager::LoadSceneTextures() {
	CreateGLTexture("textures/Plastic006_1K-JPG_Color.jpg", "plastic_black");
	CreateGLTexture("textures/Plastic014A_1K-JPG_Color.jpg", "plastic_orange");
	CreateGLTexture("textures/Wood060_1K-JPG_Color.jpg", "wood");
	CreateGLTexture("textures/WoodFloor007_1K-JPG_Color.jpg", "floor_texture");
	CreateGLTexture("textures/Wallpaper001C_1K-JPG_Color.jpg", "wall_texture");
	CreateGLTexture("textures/windowswallpaper.jpg", "laptop_screen");
	CreateGLTexture("textures/keyboard.jpg", "keyboard_texture");
	CreateGLTexture("textures/Plastic012A_1K-JPG_Color.jpg", "plastic_black_2"); // New texture
	BindGLTextures();
}

// Materials for lighting
void SceneManager::DefineObjectMaterials() {
	OBJECT_MATERIAL mat;

	mat = { glm::vec3(0.8f), glm::vec3(0.2f), 4.0f, "floor" };
	m_objectMaterials.push_back(mat);

	mat = { glm::vec3(0.7f), glm::vec3(0.1f), 2.0f, "wall" };
	m_objectMaterials.push_back(mat);

	mat = { glm::vec3(1.0f, 0.5f, 0.0f), glm::vec3(1.0f, 0.5f, 0.0f), 16.0f, "plastic" };
	m_objectMaterials.push_back(mat);

	mat = { glm::vec3(0.6f, 0.4f, 0.2f), glm::vec3(0.3f), 6.0f, "wood" };
	m_objectMaterials.push_back(mat);
}

// Lights setup
void SceneManager::SetupSceneLights() {
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// global ambient light
	m_pShaderManager->setVec3Value("ambientLight", glm::vec3(0.3f, 0.3f, 0.3f)); // luz base global

	// directional light ( like a sunlight)
	m_pShaderManager->setVec3Value("directionalLight.direction", glm::normalize(glm::vec3(-0.3f, -1.0f, -0.5f)));
	m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.2f, 0.2f, 0.2f));
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.5f, 0.5f, 0.5f));
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// point light above the laptop
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(-3.2f, 5.0f, -0.5f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.1f, 0.1f, 0.1f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.9f, 0.8f, 0.6f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
}

// Scene prep
void SceneManager::PrepareScene() {
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	///SET TEXTURE AND SCALE
	SetShaderMaterial("floor_texture");
	SetShaderTexture("floor_texture");
	SetTextureUVScale(2.0f, 2.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f); // same width and height as floor

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f; // rotate around X to stand vertically
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 9.0f, -10.0f); // move it up and behind the scene

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	////SET THE TEXTURE AND SCALE
	SetShaderMaterial("wall"); // 
	SetShaderTexture("wall_texture");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();

	// =======================
// Flashlight Construction
// =======================

		//Flashlight Body(Cylinder)
	scaleXYZ = glm::vec3(0.2f, 1.2f, 0.2f);;
	XrotationDegrees = YrotationDegrees = ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 2.25f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("plastic");
	SetShaderTexture("plastic_black");
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// Flashlight Ring (Torus)
	scaleXYZ = glm::vec3(0.24f, 0.22f, 0.24f);
	XrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(0.0f, 2.1f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("plastic");
	SetShaderTexture("plastic_orange");
	m_basicMeshes->DrawTorusMesh();

	// Flashlight Lens (Cone)
	scaleXYZ = glm::vec3(0.29f, 0.22f, 0.29f);
	XrotationDegrees = 0.0f; YrotationDegrees = 45.0f; ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 2.15f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("plastic");
	SetShaderTexture("plastic_orange");
	m_basicMeshes->DrawConeMesh(true);

	// Flashlight Switch (Box)
	scaleXYZ = glm::vec3(0.08f, 0.1f, 0.08f);
	positionXYZ = glm::vec3(0.0f, 2.65f, 0.16f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("plastic");
	SetShaderTexture("plastic_orange");
	m_basicMeshes->DrawBoxMesh();

	

	// Table Surface
	scaleXYZ = glm::vec3(12.0f, 0.2f, 4.0f);
	positionXYZ = glm::vec3(0.0f, 2.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("wood");
	SetShaderTexture("wood");
	m_basicMeshes->DrawBoxMesh();

	// Table Legs (4 legs)
	scaleXYZ = glm::vec3(0.3f, 2.0f, 0.3f);
	SetShaderMaterial("wood");
	SetShaderTexture("wood");

	positionXYZ = glm::vec3(-5.5f, 1.0f, -1.5f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(5.5f, 1.0f, -1.5f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(-5.5f, 1.0f, 1.5f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(5.5f, 1.0f, 1.5f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();


// ====================
	//laptop base(keyboard) with texture
		// ====================
		scaleXYZ = glm::vec3(2.5f, 0.1f, 1.7f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-3.2f, 2.1f, -0.31f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("keyboard_texture");  // 
	SetTextureUVScale(1.0f, 1.0f);         // 
	m_basicMeshes->DrawBoxMesh();

	// ====================
	// black frame 
	// ====================
	scaleXYZ = glm::vec3(2.4f, 0.05f, 1.5f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-3.2f, 2.91f, -1.1f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("plastic_black_2");
	SetShaderTexture("plastic_black_2");
	m_basicMeshes->DrawBoxMesh();

	// ====================
// Laptop screen with Windows texture
// ====================
	scaleXYZ = glm::vec3(2.2f, 0.10f, 1.3f);
	XrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(-3.2f, 2.91f, -1.08f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("laptop_screen");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

}



